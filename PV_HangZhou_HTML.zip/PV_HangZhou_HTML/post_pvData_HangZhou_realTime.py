# standard lib
import os, sys
from tqdm import tqdm 

# third-party lib
import requests
import pandas as pd
from curlparser import parse
from datetime import date,datetime, timedelta

# internal lib
script_dir = os.path.dirname(os.path.realpath(__file__))
from src.logger import set_logger
from src.ginlongcloud_selenium import  get_siteDay_cUrlBash
from src.post_pvData_HangZhou_realTime_Upload import last_serverDate, upload_date, save_csv



# 复原txt中的cUrlBash命令
def clean_curl(raw: str) -> str:
    """
        复原txt中的c-url
    """
    import re, textwrap
    # 1️⃣ 去掉首尾三引号
    raw = raw.strip()
    if raw.startswith(('"""', "'''")):
        raw = raw[3:-3]

    # 2️⃣ 去掉文件排版缩进
    raw = textwrap.dedent(raw).strip()

    # 3️⃣ 把 "\"<空白><换行> 合并成一个空格
    raw = re.sub(r"\\\s*[\r\n]+\s*", " ", raw)
    return raw

def download_realtime(cUrlBash, date = '2025-07-15'):
    site_list = ['欧伦1.3835MWp分布式光伏发电系统', '鸿旺1.582MWp分布式光伏发电系统']
    siteid_list = ['1299184320438401096', '1299184320438147269']
    
    dir_list = [r'G:\lcx\photoVoltaic\data\PV_Label\杭州\欧伦', r'G:\lcx\photoVoltaic\data\PV_Label\杭州\鸿旺']
    ## (1)规范输入
    parsed = parse(clean_curl(cUrlBash))
    for i in range(len(site_list)):
        if date is not None: parsed.json['beginTime'] = date    ## 自定义下载时间
        parsed.json['stationName'] = site_list[i]
        parsed.json['stationId'] = siteid_list[i]
        
        save_path = os.path.join(dir_list[i], f'电站日图表_{date}.xls')
        cleaned_headers = {k: v.strip() for k, v in parsed.header.items()}

        ## (2)获取实时数据
        breakpoint()
        response = requests.request(method=parsed.method,url=parsed.url,headers=cleaned_headers,json=parsed.json)
        if response.status_code == 200: f = open(save_path, 'wb'); f.write(response.content); f.close()
        if response.status_code != 200: logger.error(f"date:{date} data load Failed:{response.json()}! Refresh cUrlBash");

        ## (2)验证站点和时间
        data_df = pd.read_excel(save_path, index_col=None, header=None, engine='xlrd')
        assert(data_df is not None)
        data_date = data_df.iloc[0, 0].split('_')[1].split('图表')[0]
        data_siteName = data_df.iloc[2, 0].split(':')[1]
        assert(data_date == date)
        assert(data_siteName == site_list[i])

if __name__ == "__main__":
    """
        运行:
            G:\miniconda3\envs\PV\python G:\lcx\Atmos\scripts\PV_HangZhou_HTML\post_pvData_HangZhou_realTime.py
        本代码基于网页F12获取的单次令牌token, 15min有效
        【锦浪科技】您的账号: 13018905389, 请下载“锦浪云”App或进入网站www.ginlongcloud.com查看 zust123456
        基于selenium提取账户动态令牌, 下载欧伦、鸿旺两个站点数据
    """

    
    current_year_month = datetime.now().strftime("%Y-%m-%d")
    log_filename = os.path.join(r'G:\lcx\logs\PhotoVoltaic\HangZhou', f"{current_year_month}_杭州电站实时数据_欧伦-鸿旺.log")
    logger = set_logger(log_filename)

    ## 处理缺失数据
    server_date = last_serverDate()
    end_date = pd.Timestamp.today().normalize()  # 今日 00:00:00，避免时分秒干扰
    date_list = pd.date_range(start=server_date, end=end_date, freq="D").strftime("%Y-%m-%d").tolist()
    # past_days = 3
    # date_list = [(date.today() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(past_days, -1, -1)]


    # 加载网站动态token
    # web_url_oulun, usr, pwd = "https://www.ginlongcloud.com/login#/station/stationDetails/generalSituation/1299184320438401096", 13018905389, 'zust123456'
    web_url_oulun, usr, pwd = "https://v3.ginlongcloud.com#/station/stationDetails/generalSituation/1299184320438401096", 13018905389, 'zust123456'
    content = get_siteDay_cUrlBash(web_url_oulun, usr, pwd)
    if content is None:
        i, retry_num = 0, 3
        while(i<retry_num and content is None):
            i += 1
            content = get_siteDay_cUrlBash(web_url_oulun, usr, pwd)
            
 
    for cur_date in date_list:
        logger.info(f"Download Data:{cur_date}")
        download_realtime(content, cur_date)
        logger.info(f"Data:{cur_date} Local is Updated!")

    ## 更新当日数据
    for cur_date in date_list[::-1]:
        # logger.info(f"Data:{cur_date} Server is Updated!")
        upload_date(cur_date)
    for cur_date in date_list[::-1]:
        save_csv(cur_date)
    sys.exit(0)
    # breakpoint()
    # upload_realtime()


