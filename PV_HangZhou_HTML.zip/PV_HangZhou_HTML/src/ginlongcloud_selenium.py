import os, sys

from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time, json, base64, hashlib, hmac, datetime, random

# internal lib
script_dir = os.path.dirname(os.path.realpath(__file__))

# 获取电站下载token, 以下载数据
def get_siteDay_cUrlBash(web_url, usr, pwd):
    """
        传入欧伦/鸿旺电站的主页、系统用户名、密码
        返回电站下载数据的必要参数
    """

    driver = webdriver.Chrome()
    driver.scopes = [r'.*addChart.*'] 
    driver.get(web_url)
    
    # === ① 登录 ===
    # 
    # 改版时, 修改placeholder. 同时注意url的改变
    WebDriverWait(driver, 15).until(EC.presence_of_element_located((By.CLASS_NAME, "login")))
    username_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder='请填写手机号、邮箱或用户名']")))
    username_box.send_keys(usr)
    time.sleep(2)
    password_box = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder='请填写密码']")))
    password_box.send_keys(pwd)
    time.sleep(2)
    
    # 点击同意协议、登录点击
    wait = WebDriverWait(driver, 5)
    agree_checkbox = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "label.el-checkbox input.el-checkbox__original")))
    driver.execute_script("arguments[0].click();", agree_checkbox)
    login_btn = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.login-btn button.el-button--primary")))
    driver.execute_script("arguments[0].click();", login_btn)

    # === ② 触发导出 ===
    # 等待date-select区域
    date_block = WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.CSS_SELECTOR, "div.date-select")))
    # 等待第二个button
    WebDriverWait(driver, 30).until(lambda d: len(date_block.find_elements(By.CSS_SELECTOR, "div.station-export button")) >= 2)
    # 定位导出按钮, 并execute_scripts滚动到按钮位置
    export_btn = date_block.find_elements(By.CSS_SELECTOR, "div.station-export button")[1]   # 索引 1 = 第二个
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", export_btn)
    # 等待按钮可以点击
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable(export_btn))
    time.sleep(2)
    try:
        driver.requests.clear()                       # ④ 清旧日志
        export_btn.click()
    except Exception:
        driver.execute_script("arguments[0].click();", export_btn)
    
    # === ③ 拿 /station/addChart ===
    def to_curl(req):
        parts = [f"curl -X {req.method} '{req.url}'"]
        for k, v in req.headers.items():
            if k.lower() not in ('accept-encoding', 'content-length'):
                parts.append(f"-H '{k}: {v}'")
        if req.body:
            body = req.body.decode() if isinstance(req.body, bytes) else req.body
            parts.append(f"--data-raw '{body}'")
        return ' \\\n  '.join(parts)

    driver.requests
    WebDriverWait(driver, 30).until(
        lambda d: any('addChart' in r.url for r in d.requests)
    )
    cUrlBash = None
    for req in driver.requests:
        # if 'addChart' in req.url and req.response:
        if 'addChart' in req.url:
            cUrlBash = to_curl(req)
            print("\n=== cURL for addChart ===\n" + cUrlBash)
            break
    return cUrlBash

if __name__ == "__main__":
    """
        运行:
            G:\miniconda3\envs\PV\python G:\lcx\Atmos\scripts\PV_HangZhou_HTML\src\ginlongcloud_selenium.py
        【锦浪科技】您的账号: 13018905389, 请下载“锦浪云”App或进入网站www.ginlongcloud.com查看 zust123456
        (1)基于网页F12获取的单次令牌token, 15min有效
        (2)基于selenium自动测试软件, 自动登录、下载并监听抓取
        

    """
    # web_url, usr, pwd = "https://www.ginlongcloud.com/login#/station/stationDetails/generalSituation/1299184320438401096", 13018905389, 'zust123456'
    web_url, usr, pwd = "https://v3.ginlongcloud.com#/station/stationDetails/generalSituation/1299184320438401096", 13018905389, 'zust123456'
    cUrlBash = get_siteDay_cUrlBash(web_url, usr, pwd)
    breakpoint()
    
