import os, sys
import pandas as pd
from sqlalchemy import text
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from urllib.parse import quote_plus   # 避免密码里有特殊字符
import datetime
from tqdm import tqdm

sys.path.append(r'G:\lcx')
from config_global import pass_word_dict
from tqdm import tqdm 
import pdb, traceback
import requests

# 获取open-meteo处理并集成的himawari-swr数据
def get_openMeteo_swr(lat, lon, s_date, e_date, tilt, azimuth):
    try:
        # lon, lat, tilt, azimuth = 120.23106083312994, 30.450894056493027, 30, 0
        ## 指定日期查询
        # start_date, end_date = '2025-07-26', '2025-07-27'
        url = f'https://satellite-api.open-meteo.com/v1/archive?latitude={lat}&longitude={lon}&hourly=shortwave_radiation_instant,global_tilted_irradiance_instant&models=satellite_radiation_seamless&timezone=Asia%2FSingapore&tilt={tilt}&azimuth={azimuth}&temporal_resolution=native&start_date={s_date}&end_date={e_date}'

        response = requests.get(url, timeout=60)
        if response.status_code != 200:
            raise Exception(f"状态码超时/异常：{response.status_code}, url:{url}")    
        ori_df = pd.DataFrame(response.json()['hourly']).set_index('time')
        ori_df.index = pd.to_datetime(ori_df.index)

        # 暂时指定采样方式，返回值暂时不做处理, 匹配时再进行二次处理。
        # 获取的原始分辨率15分钟
        # norm the data
        df_15min = ori_df.resample("5min").interpolate("linear").resample("15min").first()
        # df_15min_2, df_15min_3 = ori_df.resample("15min").first(), ori_df.resample("15min").mean()
        # print(ori_df.iloc[8*6:10*6:, 0].values, '\n', df_15min.iloc[8*4:10*4:, 0].values, '\n', df_15min_2.iloc[8*4:10*4, 0].values,  '\n', df_15min_3.iloc[8*4:10*4, 0].values)
        return df_15min
    except Exception as e:
        print(traceback.format_exc())
        pdb.set_trace()

def upload_hist():
    table_name = 'hangzhou_label'
    host, port, usr, pwd, database = '124.71.150.155', 5432, 'postgres', pass_word_dict['password_155'], 'ZHGF'
    url = f"postgresql+psycopg2://{usr}:{quote_plus(pwd)}@{host}:{port}/{database}"
    engine = create_engine(url)
    local_dir = r'G:\lcx\photoVoltaic\data\PV_Label\杭州'
    site_list = ['欧伦', '鸿旺']

    pass

def upload_realtime():
    pass

if __name__ == "__main__":
    """
        G:\miniconda3\envs\PV\python G:\lcx\Atmos\scripts\PV_HangZhou_HTML\swr_pvData_HangZhou_realTime.py
    """
    upload_hist()