import os, sys
import pandas as pd
from sqlalchemy import text
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from urllib.parse import quote_plus   # 避免密码里有特殊字符
import datetime
# from datetime import date,datetime, timedelta
import numpy as np
from tqdm import tqdm

sys.path.append(r'G:\lcx')
from config_global import pass_word_dict
from tqdm import tqdm 
import pdb, traceback

from src.logger import set_logger
current_year_month = datetime.datetime.now().strftime("%Y-%m-%d")
log_filename = os.path.join(r'G:\lcx\logs\PhotoVoltaic\HangZhou', f"{current_year_month}_杭州电站实时数据_欧伦-鸿旺.log")
logger = set_logger(log_filename)

# 批量导出之前N天的数据
def upload_hist():
    """
        批量导出之前N天的数据
    """
    local_dir = r'G:\lcx\photoVoltaic\data\PV_Label\杭州'
    site_list = ['欧伦', '鸿旺']
    i = 1
    site_dir = os.path.join(local_dir, site_list[i])
    file_list = [os.path.join(site_dir, file) for file in os.listdir(site_dir)]

    df_list = []
    for file in file_list:
        data_df = pd.read_excel(file, index_col = 0, engine='xlrd')       # 或指定 sheet 名
        data_df = data_df.iloc[28:].copy().set_axis(data_df.iloc[27].tolist(), axis=1).reset_index(drop=True).set_index('时间').dropna(axis=1, how="all")
        data_df.index = pd.to_datetime(data_df.index)
        data_df['站点名称'] = site_list[i]
        df_list.append(data_df)
    site_df = pd.concat(df_list)
    site_df['PV(W)'] = (site_df['PV(W)'].astype(float)/1000000).round(5)   # W -> MW
    site_df = site_df.rename(columns = {'PV(W)':'PV(MW)'})
    breakpoint()
    try:
        site_df.to_sql(table_name, engine, if_exists="append")
    except IntegrityError as e:
        logger.info(f"Record:{str(data_df.index[0].date()) } Already Exists!")
        pass


def upload_realtime(cur_date = '2025-07-16'):
    table_name = 'hangzhou_label'
    host, port, usr, pwd, database = '124.71.150.155', 5432, 'postgres', pass_word_dict['password_155'], 'ZHGF'
    url = f"postgresql+psycopg2://{usr}:{quote_plus(pwd)}@{host}:{port}/{database}"
    engine = create_engine(url)
    local_dir = r'G:\lcx\photoVoltaic\data\PV_Label\杭州'
    site_list = ['欧伦', '鸿旺']

    ## (1)导入某个日期的数据(暂定每小时)
    cur_date = str(datetime.datetime.now().date())
    day_df_list = []
    for site in site_list:
        file = os.path.join(local_dir, site, f'电站日图表_{cur_date}.xls')
        data_df = pd.read_excel(file, index_col = 0, engine='xlrd')       # 或指定 sheet 名
        data_df = data_df.iloc[28:].copy().set_axis(data_df.iloc[27].tolist(), axis=1).reset_index(drop=True).set_index('时间').dropna(axis=1, how="all")
        data_df.index = pd.to_datetime(data_df.index)
        data_df['站点名称'] = site
        day_df_list.append(data_df)
    day_df = pd.concat(day_df_list)
    day_df['PV(W)'] = (day_df['PV(W)'].astype(float)/1000000).round(5)   # W -> MW
    day_df = day_df.rename(columns = {'PV(W)':'PV(MW)'})

    ## (2)对比云端-本地上传记录, 上传更新值
    sql = f"SELECT * FROM %s WHERE '时间'>= %s and '时间' <= %s"
    sql = text(f'''SELECT *FROM "{table_name}"WHERE "时间" >= :start AND "时间" < :end''')
    start_dt = datetime.datetime.strptime(cur_date, "%Y-%m-%d")          # 2025‑07‑16 00:00:00
    end_dt  = start_dt + datetime.timedelta(days=1)        
    server_df = pd.read_sql_query(sql, engine,params={"start": start_dt, "end": end_dt})
    server_dt_list = server_df['时间'].unique().tolist()
    local_dt_list = day_df.index.unique().tolist()
    new_dt_list = sorted(set(local_dt_list) - set(server_dt_list))
    if len(new_dt_list) != 0:
        for new_dt in new_dt_list:
            try:
                day_df.loc[[new_dt]].to_sql(table_name, engine, if_exists="append")
            except IntegrityError as e:
                logger.info(f"Record:{str(server_dt_list[-1])} Already Exists!")
            except Exception as e:
                logger.error(f"{traceback.format_exc()}")

        server_df = pd.read_sql_query(sql, engine,params={"start": start_dt, "end": end_dt})
        logger.info(f"Data:{str(server_df['时间'].max())} Server is Updated!")
    else:
        logger.info(f"Data:{local_dt_list[-1]} Server is Updated!")

def last_serverDate():
    table_name = 'hangzhou_label'
    host, port, usr, pwd, database = '124.71.150.155', 5432, 'postgres', pass_word_dict['password_155'], 'ZHGF'
    url = f"postgresql+psycopg2://{usr}:{quote_plus(pwd)}@{host}:{port}/{database}"
    engine = create_engine(url)

    col = '时间'
    sql_n = text(f' SELECT "{col}" FROM "{table_name}" ORDER BY "{col}" DESC LIMIT 1 ')
    df_lasted = pd.read_sql_query(sql_n, engine)
    last_date = str(df_lasted[col].iloc[0].date())
    return last_date

def upload_date(cur_date = '2025-07-16'):
    table_name = 'hangzhou_label'
    host, port, usr, pwd, database = '124.71.150.155', 5432, 'postgres', pass_word_dict['password_155'], 'ZHGF'
    url = f"postgresql+psycopg2://{usr}:{quote_plus(pwd)}@{host}:{port}/{database}"
    engine = create_engine(url)
    local_dir = r'G:\lcx\photoVoltaic\data\PV_Label\杭州'
    site_list = ['欧伦', '鸿旺']

    ## (1)导入某个日期的数据(暂定每小时)
    # cur_date = str(datetime.datetime.now().date())
    day_df_list = []
    for site in site_list:
        file = os.path.join(local_dir, site, f'电站日图表_{cur_date}.xls')
        data_df = pd.read_excel(file, index_col=None, header=None, engine='xlrd')
        data_date = data_df.iloc[0, 0].split('_')[1].split('图表')[0]
        data_df = (data_df.iloc[29:].copy().set_axis(data_df.iloc[28].tolist(), axis=1).reset_index(drop=True).set_index('时间').dropna(axis=1, how="all"))
        assert(data_date == cur_date)
        data_df.index = pd.to_datetime(data_date + ' ' + data_df.index.astype(str))
        data_df['站点名称'] = site
        day_df_list.append(data_df)
    day_df = pd.concat(day_df_list)
    day_df['PV(W)'] = (day_df['PV(W)'].astype(float)/1000000).round(5)   # W -> MW
    day_df = day_df.rename(columns = {'PV(W)':'PV(MW)'})
    day_df = day_df.drop(['序号'], axis = 1)

    ## (2)对比云端-本地上传记录, 上传更新值
    sql = f"SELECT * FROM %s WHERE '时间'>= %s and '时间' <= %s"
    sql = text(f'''SELECT *FROM "{table_name}"WHERE "时间" >= :start AND "时间" < :end''')
    start_dt = datetime.datetime.strptime(cur_date, "%Y-%m-%d")          # 2025‑07‑16 00:00:00
    end_dt  = start_dt + datetime.timedelta(days=1)        
    server_df = pd.read_sql_query(sql, engine,params={"start": start_dt, "end": end_dt})
    server_dt_list = server_df['时间'].unique().tolist()
    local_dt_list = day_df.index.unique().tolist()
    new_dt_list = sorted(set(local_dt_list) - set(server_dt_list))
    if len(new_dt_list) != 0:        
        for new_dt in new_dt_list:
            try:
                day_df.loc[[new_dt]].to_sql(table_name, engine, if_exists="append")
            except IntegrityError as e:
                logger.info(f"Record:{str(new_dt)} Already Exists!")
            except Exception as e:
                logger.error(f"{traceback.format_exc()}")

        server_df = pd.read_sql_query(sql, engine,params={"start": start_dt, "end": end_dt})
        logger.info(f"Data:{str(server_df['时间'].max())} Server is Updated!")
    else:
        logger.info(f"Data:{local_dt_list[-1]} Server is Updated!")

def save_csv(cur_date = '2025-09-28'):
    capacity_dict = {'鸿旺':1.582, '欧伦':1.3835}
    site_list = ['鸿旺', '欧伦']
    for site_name in site_list:
        local_pv_dir = os.path.join(r'G:\lcx\photoVoltaic\data\PV_Label\杭州', site_name)
        xls_file = os.path.join(local_pv_dir, f'电站日图表_{cur_date}.xls')
        csv_file = os.path.join(local_pv_dir, f'电站日表_{cur_date}.csv')

        data_df = pd.read_excel(xls_file, index_col=None, header=None, engine='xlrd')
        data_date = data_df.iloc[0, 0].split('_')[1].split('图表')[0]
        data_df = (data_df.iloc[29:].copy().set_axis(data_df.iloc[28].tolist(), axis=1).reset_index(drop=True).set_index('时间').dropna(axis=1, how="all"))
        assert(data_date == cur_date)
        data_df.index = pd.to_datetime(data_date + ' ' + data_df.index.astype(str))

        # old
        # data_df = pd.read_excel(xls_file, index_col = 0, engine='xlrd')       # 或指定 sheet 名
        # data_df = data_df.iloc[28:].copy().set_axis(data_df.iloc[27].tolist(), axis=1).reset_index(drop=True).set_index('时间').dropna(axis=1, how="all")
        # data_df.index = pd.to_datetime(data_df.index)
        data_df[['PV(W)']] = data_df[['PV(W)']].astype(np.float32)
        assert data_df['PV(W)'].isna().sum() == 0
        data_df = data_df[['PV(W)']].resample('15min').first().interpolate(method='time')
        ## reindex 96 points
        data_df = data_df.reindex(pd.date_range(f'{data_df.index[0].strftime("%Y-%m-%d")} 00:00', f'{data_df.index[-1].strftime("%Y-%m-%d")} 23:45', freq="15min")).fillna(0)    
        data_df['site_name'] = site_name
        assert data_df['PV(W)'].isna().sum() == 0
        data_df['PV(MW)'] = (data_df['PV(W)'].astype(float)/1000000).round(5)   # W -> MW
        data_df.index.name = 'time'
        data_df = data_df[['PV(MW)']].rename(columns={"PV(MW)":"power(MW)"})
        data_df['capacity(MW)'] = capacity_dict[site_name]
        data_df.to_csv(csv_file, encoding="utf-8-sig")

if __name__ == "__main__":
    """
        G:\miniconda3\envs\PV\python G:\lcx\Atmos\scripts\PV_HangZhou_HTML\post_pvData_HangZhou_realTime_Upload.py
        远端每5分钟更新, 目前每1小时更新
    """
    past_days = 3
    date_list = [(datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y-%m-%d") for i in range(past_days, -1, -1)]
    for cur_date in date_list[::-1]:
        upload_date(cur_date)
        save_csv(cur_date)