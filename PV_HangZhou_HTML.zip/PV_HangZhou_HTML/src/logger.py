import logging
import logging.handlers
from logging.handlers import RotatingFileHandler
class FlushFileHandler(logging.FileHandler):
    def emit(self, record):
        super().emit(record)
        self.flush()

class FlushingRotatingFileHandler(RotatingFileHandler):
    def emit(self, record):
        super().emit(record)
        self.flush()  # 每条日志后自动刷新


## 20250613更新版本
def set_logger(log_filename):
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # 防止重复添加 handler（常见于多次调用 set_logger 的场景）
    if logger.hasHandlers():
        logger.handlers.clear()

    # 设置日志格式
    formatter = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')

    # 控制台 handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # 自定义 FlushFileHandler（可替换为 RotatingFileHandler）
    file_handler = FlushingRotatingFileHandler(log_filename, mode='a', encoding='utf-8')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger
