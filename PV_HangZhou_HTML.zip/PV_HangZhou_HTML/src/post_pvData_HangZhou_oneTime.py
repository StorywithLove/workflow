from curlparser import parse
import requests
import os
import pandas as pd
import calendar
from datetime import datetime, timedelta
import sys, os
script_dir = os.path.dirname(os.path.realpath(__file__))
from tqdm import tqdm 

import requests
from ginlongcloud_selenium import  get_siteDay_cUrlBash

# 复原txt中的cUrlBash命令
def clean_curl(raw: str) -> str:
    """
        复原txt中的c-url
    """
    import re, textwrap
    # 1️⃣ 去掉首尾三引号
    raw = raw.strip()
    if raw.startswith(('"""', "'''")):
        raw = raw[3:-3]

    # 2️⃣ 去掉文件排版缩进
    raw = textwrap.dedent(raw).strip()

    # 3️⃣ 把 "\"<空白><换行> 合并成一个空格
    raw = re.sub(r"\\\s*[\r\n]+\s*", " ", raw)
    return raw

# 基于txt_path中的cUrlBash获取response
def get_login_response(txt_path):
    """
        基于txt_path中的cUrlBash获取response
    """
    f = open(os.path.join(script_dir, txt_path), "r", encoding="utf-8"); content = f.read();f.close();    
    parsed = parse(clean_curl(content))
    cleaned_headers = {k: v.strip() for k, v in parsed.header.items()}
    response = requests.request(method=parsed.method,url=parsed.url,headers=cleaned_headers,json=parsed.json)
    return response

# 基于txt_path中的cUrlBash获取response, 并保存数据
def get_tempData_save(txt_path, date = None, save_path=os.path.join(script_dir, f'./test.xls')):
    """
        基于txt_path中的cUrlBash获取response, 并保存数据
    """
    ## (0)规划化cUrlBash
    f = open(os.path.join(script_dir, txt_path), "r", encoding="utf-8"); content = f.read();f.close();    
    parsed = parse(clean_curl(content))
    if date is not None: parsed.json['beginTime'] = date
    cleaned_headers = {k: v.strip() for k, v in parsed.header.items()}

    ## (1)获取resp-date
    response = requests.request(method=parsed.method,url=parsed.url,headers=cleaned_headers,json=parsed.json)

    if response.status_code == 200: f = open(save_path, 'wb'); f.write(response.content); f.close()
    if response.status_code != 200: print(f"date:{date} data load Failed:{response.json()}! Refresh cUrlBash");return None

    ## (2)valid-data
    data_df = pd.read_excel(save_path, index_col = 0, engine='xlrd')
    assert(data_df is not None)
    data_date = data_df.iloc[28:].copy().set_axis(data_df.iloc[27].tolist(), axis=1).reset_index(drop=True)['时间'].iloc[0].split(' ')[0]
    assert(data_date == date)
    return 0

if __name__ == "__main__":
    """
        运行:
            G:\miniconda3\envs\PV\python G:\lcx\Atmos\scripts\PV_HangZhou_HTML\post_pvData_HangZhou_oneTime.py
        本代码基于网页F12获取的单次令牌token, 15min有效
        【锦浪科技】您的账号: 13018905389, 请下载“锦浪云”App或进入网站www.ginlongcloud.com查看 zust123456

        content-MD5, 1.对 Body 进行 MD5 加密；2. 对加密内容转换为 128 位的二进制数组；3. 对二进制数组进行 Base64 编码。
        au, 授权信息
        content-MD5, 请求体的MD5哈希, 常做Base64编码
        Time, 某次请求时间
        (1) 三者逻辑关系: au依赖content-MD5、Time
        (2) 网页JS动态生成: 请求体json-MD5-Base64得到content-MD5, time+MD5+else->令牌
    """

    ## (1)基于15分钟临时令牌下载
    date = '2025-07-14'
    data_flag = get_tempData_save("./txt_data/ginlongcloud_OuLunDay.txt", date, os.path.join(script_dir, f'./{date}.xls'))
    breakpoint()




