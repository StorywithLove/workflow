from flask import Flask, request, jsonify
from sqlalchemy import create_engine, text
from datetime import datetime
from urllib.parse import quote_plus   # 避免密码里有特殊字符
from datetime import datetime, timedelta
import pandas as pd
import os, sys

host, port, usr, pwd, database = '124.71.150.155', 5432, 'postgres', 'Drey7&Aj9IpKHA41', 'ZHGF'
url = f"postgresql+psycopg2://{usr}:{quote_plus(pwd)}@{host}:{port}/{database}"
engine = create_engine(url, pool_recycle=3600)

app = Flask(__name__)
@app.route("/pv/hangzhou", methods=["GET"])
def get_power():
    # 1️⃣ 读取并校验参数
    date_str = request.args.get("date")
    # name     = request.args.get("name")
    if not date_str:
        return jsonify({"error": "Missing 'date' "}), 400
    
    if date_str.lower() == 'realtime':
        # 查询24小时内最新一条记录
        start_dt = datetime.now().replace(hour = 0, second=0, microsecond=0)
        end_dt = start_dt + timedelta(days=1)  # 下一分钟为结束时间
    else:
        try:
            start_dt = datetime.strptime(date_str, "%Y-%m-%d")
            end_dt   = start_dt + timedelta(days = 1)
        except ValueError:
            return jsonify({"error": "Invalid date format, expected YYYY-MM-DD"}), 400

    # 2️⃣ 查询数据库（参数绑定可防 SQL 注入）
    table_name = 'hangzhou_label'
    sql = text(f'''SELECT *FROM "{table_name}"WHERE "时间" >= :start AND "时间" < :end''')
    rows = pd.read_sql_query(sql, engine,params={"start": start_dt, "end": end_dt})


    if len(rows) == 0:
        return jsonify({"error": "No data found"}), 404

    rows = rows.sort_values(by = ['时间'])
    rows['时间'] = rows['时间'].dt.tz_localize("Asia/Shanghai")  # 保证带 +08:00
    # ③ 组装返回列表
    print(rows.iloc[0]['时间'], rows.iloc[0].values)
    data = [
        {
            "time":   rows.iloc[i]['时间'].isoformat(timespec="minutes"),
            "status": rows.iloc[i]['工作状态'],                 # 工作状态
            "power(MW)":  rows.iloc[i]['PV(MW)'],          # PV(MW)
            "name":   rows.iloc[i]['站点名称']                  # 站点名称
        }
        for i in range(len(rows))
    ]

    return jsonify({"date": date_str, "data": data})

if __name__ == "__main__":
    """
        /root/miniconda3/envs/pv/bin/python /root/lcx/ginlongcloud_app.py
        curl "http://localhost:8000/api/v1/power?date=2025-07-16"
    """
    app.run(host="0.0.0.0", port=5007)
