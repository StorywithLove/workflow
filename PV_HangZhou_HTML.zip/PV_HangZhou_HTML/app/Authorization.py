# authorization.py
import base64
import hashlib
import hmac
import json
from datetime import datetime, timezone
import requests

def hmac_sha1_encrypt(text: str, secret: str) -> str:
    """HmacSHA1 加签并做 Base64."""
    digest = hmac.new(secret.encode('utf-8'),
                      text.encode('utf-8'),
                      hashlib.sha1).digest()
    return base64.b64encode(digest).decode('utf-8')

def get_gmt_time() -> str:
    """返回符合 RFC‑1123 的 GMT 字符串，示例: 'Wed, 16 Jul 2025 15:20:30 GMT'"""
    return datetime.now(timezone.utc).strftime('%a, %d %b %Y %H:%M:%S GMT')

def get_digest(body: str) -> str:
    """计算 body 的 MD5 再 Base64."""
    md5_bytes = hashlib.md5(body.encode('utf-8')).digest()
    return base64.b64encode(md5_bytes).decode('utf-8')

def main():
    key        = ''          # API key
    key_secret = ''          # API secret

    payload = {"pageNo": 1, "pageSize": 10}
    body    = json.dumps(payload, separators=(',', ':'))   # 与 fastjson.toJSONString 行为一致

    content_md5 = get_digest(body)
    gmt_date    = get_gmt_time()
    path        = '/v1/api/userStationList'

    # stringToSign = METHOD \n MD5 \n Content‑Type \n Date \n path
    string_to_sign = '\n'.join([
        'POST',
        content_md5,
        'application/json',
        gmt_date,
        path
    ])

    signature = hmac_sha1_encrypt(string_to_sign, key_secret)

    url = f'https://api.ginlong.com:13333{path}'   # 修改为真实域名

    headers = {
        'Content-Type': 'application/json;charset=UTF-8',
        'Authorization': f'API {key}:{signature}',
        'Content-MD5':   content_md5,
        'Date':          gmt_date,
    }

    resp = requests.post(url, headers=headers, data=body, timeout=10)
    print(f'{resp.status_code}  {resp.text}')
    breakpoint()

if __name__ == '__main__':
    """
        G:\miniconda3\envs\PV\python G:\lcx\Atmos\scripts\PV_HangZhou_HTML\Authorization.py
        基于厂家API获取数据: https://oss.ginlong.com/templet/%E9%94%A6%E6%B5%AA%E4%BA%91%E5%B9%B3%E5%8F%B0API%E6%96%87%E6%A1%A3V2.0.2.pdf#page=4.31 
        三个关键要素:
            key, key_secret, url
        hmac_sha1_encrypt无法从已有结果中推导出原始的key和key_secret. 该路线失败
    """

    main()
